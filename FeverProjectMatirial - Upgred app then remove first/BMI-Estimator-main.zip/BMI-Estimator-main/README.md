# BMI-Estimator
A BMI Estimator is an app with good UI which calculates the BMI of a person based on the person's age, sex, height and weight etc and also tells the person about its current health status.
